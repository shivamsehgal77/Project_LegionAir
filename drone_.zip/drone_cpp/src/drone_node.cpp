#include <rclcpp/rclcpp.hpp> ///< Include the ROS 2 library.
#include "drone_cpp/drone_node.hpp"///< Include the DroneNode class.

void DroneNode::handle_request(///< Handle the request from the service.
    const std::shared_ptr<DropDroneSrv::Request> request,
    const std::shared_ptr<DropDroneSrv::Response> response)
{
    
    auto req= request->drop;///< Get the request.
    response->dropped = true;///< Set the response to true.
    RCLCPP_INFO(this->get_logger(), "Drone %d dropped", id_);///< Log the drone drop.
    //rclcpp::shutdown();///< Shutdown the ROS 2 system.
}

void DroneNode::callback_left(const drone_swarm_msgs::msg::DroneStatus::SharedPtr msg)///< Callback function for the left neighbor.
{
    phase_angel_left_ = msg->phase_angle.data;///< Get the phase angle of the left neighbor.
    radius_left_ = msg->radius.data;///< Get the radius of the left neighbor.
}
void DroneNode::callback_right(const drone_swarm_msgs::msg::DroneStatus::SharedPtr msg)///< Callback function for the right neighbor.
{
    phase_angel_right_ = msg->phase_angle.data;///< Get the phase angle of the right neighbor.
    radius_right_ = msg->radius.data;///< Get the radius of the right neighbor.
}

void DroneNode::timer_callback()///< Timer callback function.
{
    status_msg_.id.data = id_;///< Set the drone id.
    status_msg_.anchor.data = anchor_;///< Set the anchor status.
    status_msg_.phase_angle.data = static_cast<float>(phase_angel_);///< Set the phase angle.
    status_msg_.radius.data = static_cast<float>(radius_);///< Set the radius.
    status_msg_.neighbor_left.data = neighbour_left_;///< Set the left neighbor id.
    status_msg_.neighbor_right.data = neighbour_right_;///< Set the right neighbor id.
    publisher_->publish(status_msg_);///< Publish the status message.
}
int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);///< Initialize the ROS 2 system.
    auto drone_node = std::make_shared<DroneNode>("drone_number");///< Create a DroneNode.
    rclcpp::spin(drone_node);///< Spin the node to continuously publish messages.
    rclcpp::shutdown();//< Shutdown the ROS 2 system.
}